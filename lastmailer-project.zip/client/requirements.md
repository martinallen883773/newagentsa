## Packages
framer-motion | Smooth page transitions and UI animations
date-fns | Formatting dates for email history

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
